let grassBlades = [];

function setup() {
  createCanvas(600, 400);
  // Criar várias graminhas
  for (let i = 0; i < 100; i++) {
    grassBlades.push(new Grass(random(width), random(height/2, height)));
  }
}

function draw() {
  background(135, 206, 235); // Céu azul
  drawSun();
  drawClouds();
  
  // Desenhar e mover as graminhas
  for (let blade of grassBlades) {
    blade.move();
    blade.display();
  }
  
  drawFlowers();
}

// Classe para as graminhas
class Grass {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.height = random(10, 20);
    this.angleOffset = random(TWO_PI);
  }
  
  move() {
    // Balanço suave ao vento
    this.angle = sin(frameCount * 0.02 + this.angleOffset) * 0.3;
  }
  
  display() {
    push();
    translate(this.x, this.y);
    rotate(this.angle);
    stroke(34, 139, 34);
    strokeWeight(2);
    line(0, 0, 0, -this.height);
    pop();
  }
}

// Desenhar o sol
function drawSun() {
  fill(255, 204, 0);
  noStroke();
  ellipse(80, 80, 60, 60);
}

// Desenhar nuvens
function drawClouds() {
  fill(255);
  noStroke();
  ellipse(200, 80, 50, 30);
  ellipse(230, 70, 50, 30);
  ellipse(260, 80, 50, 30);
  
  ellipse(400, 50, 70, 40);
  ellipse(430, 50, 70, 40);
  ellipse(460, 50, 70, 40);
}

// Desenhar flores
function drawFlowers() {
  // Flores pequenas
  fill(255, 0, 255);
  for (let i = 0; i < 10; i++) {
    let x = random(50, width - 50);
    let y = random(height/2 + 20, height - 20);
    ellipse(x, y, 8, 8);
    // Pétalas
    fill(255, 192, 203);
    for (let j = 0; j < 8; j++) {
      let angle = TWO_PI / 8 * j;
      let px = x + cos(angle) * 4;
      let py = y + sin(angle) * 4;
      ellipse(px, py, 4, 4);
    }
  }
}